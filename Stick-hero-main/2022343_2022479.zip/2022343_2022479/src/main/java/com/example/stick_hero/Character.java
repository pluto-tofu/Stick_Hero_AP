package com.example.stick_hero;

public class Character {
    //private ImgView character_sprite;
    //private Arraylist<String> character_idle;
    //private Arraylist<String> character_moving;

    //private idle_animation(){}
    //private moving_animation(){}
}
