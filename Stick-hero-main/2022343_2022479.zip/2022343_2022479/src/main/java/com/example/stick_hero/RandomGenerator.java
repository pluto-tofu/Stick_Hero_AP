package com.example.stick_hero;

import java.util.Random;

// singleton class for random number generation
// application of singleton design pattern for creating only a single
// instance of a random number generator.


public class RandomGenerator {
    private static RandomGenerator r = null;
    private Random ra;

    private RandomGenerator() {
        this.ra = new Random();
    }
    public static RandomGenerator get_instance(){
        if(r == null){
            r = new RandomGenerator();
        }
        return r;
    }

    public static RandomGenerator getR() {
        return r;
    }

    public static void setR(RandomGenerator r) {
        RandomGenerator.r = r;
    }

    public Random getRa() {
        return ra;
    }

    public void setRa(Random ra) {
        this.ra = ra;
    }
}
